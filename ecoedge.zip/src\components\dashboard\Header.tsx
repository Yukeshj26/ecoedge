export default function Header() {
  return (
    <header className="flex items-center justify-between mb-8">
      <div>
        <h2 className="text-3xl font-bold">
          Central Sustainability Dashboard
        </h2>

        <p className="text-gray-400 mt-1">
          Real-time AI-powered energy intelligence
        </p>
      </div>

      <div className="flex gap-4">
        <div className="bg-green-500/20 text-green-400 px-4 py-2 rounded-xl">
          MQTT Connected
        </div>

        <div className="bg-cyan-500/20 text-cyan-400 px-4 py-2 rounded-xl">
          CSI: 87
        </div>
      </div>
    </header>
  );
}