"use client";

type Props = {
  telemetry: any;
};

export default function DigitalTwin({
  telemetry,
}: Props) {

  const healthy =
    telemetry?.anomaly === "NORMAL";

  return (
    <div className="bg-[#111827] rounded-2xl p-8 mt-8">

      <h2 className="text-2xl font-bold mb-8">
        Digital Twin
      </h2>

      <div className="flex items-center justify-between">

        {/* Solar */}
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-yellow-400 animate-pulse" />
          <p className="mt-3 text-lg">
            Solar Source
          </p>
        </div>

        {/* Power Flow */}
        <div className="flex-1 h-2 mx-6 rounded bg-cyan-500 animate-pulse" />

        {/* Battery */}
        <div className="flex flex-col items-center">
          <div
            className={`
              w-32 h-20 rounded-xl border-4
              flex items-center justify-center
              text-xl font-bold
              ${
                healthy
                  ? "border-green-400"
                  : "border-red-500"
              }
            `}
          >
            {telemetry?.battery}%
          </div>

          <p className="mt-3 text-lg">
            Battery Bank
          </p>
        </div>

        {/* Grid Flow */}
        <div className="flex-1 h-2 mx-6 rounded bg-pink-500 animate-pulse" />

        {/* Grid */}
        <div className="flex flex-col items-center">
          <div
            className={`
              w-24 h-24 rounded-full
              ${
                healthy
                  ? "bg-green-500"
                  : "bg-red-500 animate-pulse"
              }
            `}
          />

          <p className="mt-3 text-lg">
            Microgrid
          </p>
        </div>

      </div>

      {/* Telemetry */}
      <div className="grid grid-cols-4 gap-4 mt-10">

        <div className="bg-black/30 p-4 rounded-xl">
          Voltage:
          <div className="text-2xl mt-2">
            {telemetry?.voltage}V
          </div>
        </div>

        <div className="bg-black/30 p-4 rounded-xl">
          Power:
          <div className="text-2xl mt-2">
            {telemetry?.power}W
          </div>
        </div>

        <div className="bg-black/30 p-4 rounded-xl">
          CSI:
          <div className="text-2xl mt-2">
            {telemetry?.csi}
          </div>
        </div>

        <div className="bg-black/30 p-4 rounded-xl">
          Status:
          <div className="text-2xl mt-2">
            {telemetry?.anomaly}
          </div>
        </div>

      </div>

    </div>
  );
}

