import pandas as pd
import numpy as np

from sklearn.ensemble import IsolationForest

import joblib

rows = 1000

data = pd.DataFrame({

    "voltage":
        np.random.normal(12.5, 0.5, rows),

    "battery":
        np.random.normal(80, 10, rows),

    "power":
        np.random.normal(50, 15, rows),

    "csi":
        np.random.normal(75, 8, rows)
})

model = IsolationForest(
    contamination=0.05,
    random_state=42
)

model.fit(data)

joblib.dump(
    model,
    "anomaly_detector.pkl"
)

print(
    "Anomaly model trained successfully"
)