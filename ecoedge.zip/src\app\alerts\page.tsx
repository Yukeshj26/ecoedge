import Sidebar from "@/components/dashboard/Sidebar";

export default function AlertsPage() {

  const alerts = [
    "POWER SURGE — School Grid",
    "LOW BATTERY — Village Grid",
    "VOLTAGE DROP — Clinic Grid",
  ];

  return (
    <main className="flex min-h-screen bg-[#0B1120] text-white">

      <Sidebar />

      <section className="flex-1 p-8">

        <h1 className="text-4xl font-bold mb-8">
          Alerts
        </h1>

        <div className="space-y-4">

          {alerts.map((alert) => (
            <div
              key={alert}
              className="bg-red-500/20 border border-red-500 rounded-xl p-4"
            >
              {alert}
            </div>
          ))}

        </div>

      </section>

    </main>
  );
}