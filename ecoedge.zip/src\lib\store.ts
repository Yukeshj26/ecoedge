export let latestTelemetry = {
  voltage: 0,
  current: 0,
  power: 0,
  battery: 0,
  solarInput: 0,
  load: 0,
  relay: false,
  csi: 0,
  status: "WAITING",
};