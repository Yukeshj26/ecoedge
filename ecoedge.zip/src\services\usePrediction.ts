"use client";

import { useEffect, useState } from "react";

export default function usePrediction(
  latest: any
) {

  const [prediction, setPrediction] =
    useState<number | null>(null);

  useEffect(() => {

    if (!latest) return;

    const predict = async () => {

      try {

        console.log("Sending to AI:", latest);

        const response = await fetch(
          "http://127.0.0.1:5000/predict",
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({

              voltage:
                latest.voltage || 0,

              battery:
                latest.battery || 0,

              power:
                latest.power || 0,

              solar:
                latest.solar || 0,

              load:
                latest.load || 0,

              csi:
                latest.csi || 0,
            }),
          }
        );

        console.log(
          "Response Status:",
          response.status
        );

        const data =
          await response.json();

        console.log(
          "Prediction Result:",
          data
        );

        if (
          data.backup_time !== undefined
        ) {
          setPrediction(
            Number(data.backup_time)
          );
        }

      } catch (error) {

        console.error(
          "Prediction Error:",
          error
        );

      }
    };

    predict();

  }, [latest]);

  return prediction;
}