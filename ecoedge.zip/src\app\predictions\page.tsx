import Sidebar from "@/components/dashboard/Sidebar";

export default function PredictionsPage() {

  return (
    <main className="flex min-h-screen bg-[#0B1120] text-white">

      <Sidebar />

      <section className="flex-1 p-8">

        <h1 className="text-4xl font-bold mb-8">
          AI Predictions
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

          <div className="bg-[#111827] rounded-2xl p-6">
            <h2 className="text-2xl font-bold mb-4">
              Predicted Backup
            </h2>

            <p className="text-5xl text-orange-400 font-bold">
              104 hrs
            </p>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6">
            <h2 className="text-2xl font-bold mb-4">
              Outage Probability
            </h2>

            <p className="text-5xl text-red-400 font-bold">
              8%
            </p>
            </div>

        </div>

      </section>

    </main>
  );
}