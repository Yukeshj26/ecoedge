import Sidebar from "@/components/dashboard/Sidebar";

export default function SettingsPage() {

  return (
    <main className="flex min-h-screen bg-[#0B1120] text-white">

      <Sidebar />

      <section className="flex-1 p-8">

        <h1 className="text-4xl font-bold mb-8">
          Settings
        </h1>

        <div className="bg-[#111827] rounded-2xl p-8 space-y-4">

          <div>
            MQTT Broker: broker.hivemq.com
          </div>

          <div>
            Database: InfluxDB
          </div>

          <div>
            Telemetry Interval: 3s
          </div>

        </div>

      </section>

    </main>
  );
}