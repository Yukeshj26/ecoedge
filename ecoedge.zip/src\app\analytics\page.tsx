"use client";

import { useEffect, useState } from "react";
import Sidebar from "@/components/dashboard/Sidebar";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

export default function AnalyticsPage() {
  const [history, setHistory] = useState<any[]>([]);

  const [stats, setStats] = useState({
    avgPower: 0,
    avgVoltage: 0,
    avgBattery: 0,
    peakPower: 0,
  });

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await fetch("/api/telemetry/history");
        const json = await res.json();

        if (!json.success || !json.data) return;

        // Normalize raw telemetry
        const normalized = json.data.map((d: any) => ({
          time: new Date(d.time).getTime(),
          power: d._field === "power" ? d._value : 0,
          voltage: d._field === "voltage" ? d._value : 0,
          battery: d._field === "battery" ? d._value : 0,
        }));

        // Merge same timestamps
        const grouped = new Map<number, any>();

        normalized.forEach((d: any) => {
          if (!grouped.has(d.time)) {
            grouped.set(d.time, {
              time: d.time,
              power: 0,
              voltage: 0,
              battery: 0,
            });
          }

          const existing = grouped.get(d.time);

          if (d.power) existing.power = d.power;
          if (d.voltage) existing.voltage = d.voltage;
          if (d.battery) existing.battery = d.battery;
        });

        const finalData = Array.from(grouped.values())
          .sort((a, b) => a.time - b.time)
          .slice(-30);

        setHistory(finalData);

        // Avoid empty division crashes
        if (finalData.length === 0) return;

        // Compute stats
        const avgPower =
          finalData.reduce((a, b) => a + b.power, 0) / finalData.length;

        const avgVoltage =
          finalData.reduce((a, b) => a + b.voltage, 0) / finalData.length;

        const avgBattery =
          finalData.reduce((a, b) => a + b.battery, 0) / finalData.length;

        const peakPower = Math.max(...finalData.map((d) => d.power));

        setStats({
          avgPower,
          avgVoltage,
          avgBattery,
          peakPower,
        });
      } catch (err) {
        console.error("Analytics fetch error:", err);
      }
    };

    fetchAnalytics();

    const interval = setInterval(fetchAnalytics, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <main className="flex min-h-screen bg-[#0B1120] text-white">
      <Sidebar />

      <section className="flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Analytics</h1>
          <p className="text-gray-400">
            Rural microgrid telemetry intelligence and historical performance
            monitoring
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <div className="bg-[#111827] rounded-2xl p-6">
            <p className="text-gray-400 mb-2">Avg Power</p>
            <h2 className="text-3xl font-bold text-pink-400">
              {stats.avgPower.toFixed(1)}W
            </h2>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6">
            <p className="text-gray-400 mb-2">Avg Voltage</p>
            <h2 className="text-3xl font-bold text-cyan-400">
              {stats.avgVoltage.toFixed(2)}V
            </h2>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6">
            <p className="text-gray-400 mb-2">Avg Battery</p>
            <h2 className="text-3xl font-bold text-green-400">
              {stats.avgBattery.toFixed(0)}%
            </h2>
          </div>

          <div className="bg-[#111827] rounded-2xl p-6">
            <p className="text-gray-400 mb-2">Peak Power</p>
            <h2 className="text-3xl font-bold text-yellow-400">
              {stats.peakPower.toFixed(1)}W
            </h2>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Power Trend */}
          <div className="bg-[#111827] rounded-2xl p-6">
            <h2 className="text-2xl font-bold mb-6">
              Power Consumption Trend
            </h2>

            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#374151"
                  />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="power"
                    stroke="#EC4899"
                    strokeWidth={3}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Voltage Trend */}
          <div className="bg-[#111827] rounded-2xl p-6">
            <h2 className="text-2xl font-bold mb-6">
              Voltage Stability
            </h2>

            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#374151"
                  />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="voltage"
                    stroke="#06B6D4"
                    strokeWidth={3}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Sustainability Panel */}
        <div className="bg-[#111827] rounded-2xl p-8 mt-10">
          <h2 className="text-2xl font-bold mb-6">
            Sustainability Intelligence
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-black/30 p-6 rounded-xl">
              <p className="text-gray-400">Grid Stability</p>
              <h3 className="text-4xl font-bold text-green-400 mt-3">
                92%
              </h3>
            </div>

            <div className="bg-black/30 p-6 rounded-xl">
              <p className="text-gray-400">Rural Reliability</p>
              <h3 className="text-4xl font-bold text-cyan-400 mt-3">
                HIGH
              </h3>
            </div>

            <div className="bg-black/30 p-6 rounded-xl">
              <p className="text-gray-400">Sustainability Score</p>
              <h3 className="text-4xl font-bold text-yellow-400 mt-3">
                88
              </h3>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}