interface StatCardProps {
  title: string;
  value: string;
  color?: string;
}

export default function StatCard({
  title,
  value,
  color = "text-white",
}: StatCardProps) {
  return (
    <div className="bg-[#111827] border border-gray-800 rounded-2xl p-6 shadow-lg">
      <p className="text-gray-400">{title}</p>

      <h2 className={`text-4xl font-bold mt-3 ${color}`}>
        {value}
      </h2>
    </div>
  );
}