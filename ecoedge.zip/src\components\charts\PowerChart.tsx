"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

export default function PowerChart({
  data,
}: {
  data: any[];
}) {

  console.log("CHART DATA:", data);

  return (

    <div className="bg-[#111827] p-6 rounded-2xl w-full h-[400px]">

      <h2 className="text-xl font-semibold mb-4">
        Voltage History
      </h2>

      <ResponsiveContainer
        width="100%"
        height="100%"
      >

        <LineChart data={data}>

          <CartesianGrid strokeDasharray="3 3" />

          <XAxis dataKey="time" />

          <YAxis />

          <Tooltip />

          <Line
            type="monotone"
            dataKey="power"
            stroke="#22D3EE"
            strokeWidth={3}
            dot={false}
          />

        </LineChart>

      </ResponsiveContainer>

    </div>
  );
}