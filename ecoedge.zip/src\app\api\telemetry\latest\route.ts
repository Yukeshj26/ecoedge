import { NextResponse } from "next/server";
import { queryApi, bucket } from "@/lib/influx";
import { calculateCSI } from "@/lib/csi";
import { predictMaintenance } from "@/lib/predictive";
import { detectAnomaly } from "@/lib/anomaly";
export async function GET() {
  const query = `
    from(bucket: "${bucket}")
      |> range(start: -5m)
      |> filter(fn: (r) => r._measurement == "ecoedge")
      |> last()
  `;

  const rows: any[] = [];

  return new Promise((resolve) => {
    queryApi.queryRows(query, {
      next(row, tableMeta) {
        const data = tableMeta.toObject(row);
        rows.push(data);
      },

      error(error) {
        resolve(
          NextResponse.json({
            success: false,
            error: error.message,
          })
        );
      },

      complete() {
        const result: any = {};

        rows.forEach((r) => {
          result[r._field] = r._value;
        });
        result.csi = calculateCSI( result.voltage, result.battery, result.power );
         result.anomaly = detectAnomaly( result.voltage, result.battery, result.power );
            
        result.maintenance =
        predictMaintenance(
            result.battery,
            result.voltage,
            result.power
        );
       resolve(
          NextResponse.json({
            success: true,
            data: result,
          })
        );
       
      },
    });
  });
}
