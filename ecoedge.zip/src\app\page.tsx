"use client";

import Sidebar from "@/components/dashboard/Sidebar";
import Header from "@/components/dashboard/Header";
import StatCard from "@/components/cards/StatCard";
import PowerChart from "@/components/charts/PowerChart";
import DigitalTwin from "@/components/digitaltwin/DigitalTwin";
import useTelemetry from "@/services/useTelemetry";
import usePrediction from "@/services/usePrediction";
export default function Home() {

  const {
    latest,
    history
  } = useTelemetry();

  const prediction =
  usePrediction(latest);

  const anomaly = latest?.anomaly || "NORMAL";

  return (
    <main className="flex bg-[#0B1120] text-white min-h-screen">

      <Sidebar />

      <section className="flex-1 p-8">

        <Header />

        <div className="grid grid-cols-1 md:grid-cols-7 gap-6 mb-8">

  <StatCard
    title="Voltage"
    value={
      latest
        ? `${latest.voltage}V`
        : "..."
    }
    color="text-cyan-400"
  />

  <StatCard
    title="Battery"
    value={
      latest
        ? `${latest.battery}%`
        : "..."
    }
    color="text-green-400"
  />

  <StatCard
    title="CSI Score"
    value={
      latest
        ? `${latest.csi}`
        : "..."
    }
    color="text-yellow-400"
  />

  <StatCard
    title="Power"
    value={
      latest
        ? `${latest.power}W`
        : "..."
    }
    color="text-pink-400"
  />

<StatCard title="System Status"
 value={ latest ? latest.status : "WAITING" }
 color={ latest ? latest.status === "OPTIMAL" ? "text-green-400" : latest.status === "WARNING" ? "text-yellow-400" : "text-red-400" : "text-gray-400" } />
  <StatCard
  title="Predicted Backup"
  value={
    prediction
      ? `${prediction.toFixed(1)} hrs`
      : "Predicting..."
  }
  color="text-orange-400"
  />
  <StatCard
  title="AI Anomaly"
  value={anomaly}
  color={
    anomaly === "NORMAL"
      ? "text-green-400"
      : "text-red-400"
  }
  />
  <StatCard
    title="Maintenance Risk"
    value={
      latest?.maintenance?.status || "LOW"
    }
    color={
      latest?.maintenance?.status === "CRITICAL"
        ? "text-red-500"
        : latest?.maintenance?.status === "MEDIUM"
        ? "text-yellow-400"
        : "text-green-400"
    }
  />


</div>

        <PowerChart data={history} />
        <DigitalTwin telemetry={latest} />
      </section>

    </main>
  );
}