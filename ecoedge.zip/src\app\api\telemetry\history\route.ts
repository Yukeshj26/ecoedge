import { NextResponse } from "next/server";
import { queryApi, bucket } from "@/lib/influx";

export async function GET() {

  const query = `
    from(bucket: "${bucket}")
      |> range(start: -30m)
      |> filter(fn: (r) => r._measurement == "ecoedge")
      |> sort(columns: ["_time"])
  `;

  const rows: any[] = [];

  return new Promise((resolve) => {

    queryApi.queryRows(query, {

      next(row, tableMeta) {

        const data =
          tableMeta.toObject(row);

        rows.push(data);
      },

      error(error) {

        console.error(error);

        resolve(
          NextResponse.json({
            success: false,
            error: error.message,
          })
        );
      },

      complete() {

        console.log(
          "HISTORY ROWS:",
          rows.length
        );

        resolve(
          NextResponse.json({
            success: true,
            data: rows,
          })
        );
      },
    });
  });
}