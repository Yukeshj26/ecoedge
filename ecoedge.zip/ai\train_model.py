import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
import joblib

# Generate training data

data = []

for _ in range(1000):

    voltage = np.random.randint(210, 240)
    battery = np.random.randint(20, 100)
    power = np.random.randint(100, 1000)

    # realistic backup estimation
    backup_time = battery / (power / 50)

    data.append([
        voltage,
        battery,
        power,
        backup_time
    ])

df = pd.DataFrame(
    data,
    columns=[
        "voltage",
        "battery",
        "power",
        "backup_time"
    ]
)

X = df[[
    "voltage",
    "battery",
    "power"
]]

y = df["backup_time"]

model = RandomForestRegressor()

model.fit(X, y)

joblib.dump(model, "backup_predictor.pkl")

print("Model trained successfully")