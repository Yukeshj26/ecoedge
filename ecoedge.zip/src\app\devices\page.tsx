"use client";

import { useEffect, useState } from "react";

import Sidebar from "@/components/dashboard/Sidebar";

export default function DevicesPage() {

  const [devices, setDevices] =
    useState<any[]>([]);

  const [deviceId, setDeviceId] =
    useState("");

  const [deviceName, setDeviceName] =
    useState("");

  const [showModal, setShowModal] =
    useState(false);

  // Fetch live devices
  useEffect(() => {

    const fetchDevices = async () => {

      try {

        const res = await fetch(
          "/api/devices"
        );

        const json = await res.json();

        if (json.success) {
          setDevices(json.data);
        }

      } catch (err) {
        console.error(err);
      }

    };

    fetchDevices();

    const interval = setInterval(
      fetchDevices,
      3000
    );

    return () =>
      clearInterval(interval);

  }, []);

  // Add local device
  const handleAddDevice = () => {

    if (!deviceId || !deviceName) {
      return;
    }

    const newDevice = {
      device: deviceId,
      name: deviceName,
      voltage: "--",
      battery: "--",
      power: "--"
    };

    setDevices((prev) => [
      ...prev,
      newDevice
    ]);

    setDeviceId("");
    setDeviceName("");
  };

  return (

    <main className="
      flex min-h-screen
      bg-[#0B1120]
      text-white
    ">

      <Sidebar />

      <section className="flex-1 p-8">

        {/* Header */}

        <div className="
          flex items-center
          justify-between
          mb-8
        ">

          <h1 className="text-4xl font-bold">
            Live Microgrids
          </h1>

          <button
            onClick={() =>
              setShowModal(true)
            }
            className="
              bg-cyan-500
              text-black
              px-5 py-3
              rounded-xl
              font-bold
              hover:scale-105
              transition
            "
          >
            + Add Device
          </button>

        </div>

        {/* Device Cards */}

        <div className="
          grid grid-cols-1
          md:grid-cols-3
          gap-6
        ">

          {devices.map((device) => (

            <div
              key={device.device}
              className={`
                rounded-2xl
                p-6
                border-2
                transition-all
                ${
                  device.battery > 70
                    ? "bg-green-500/10 border-green-500"
                    : device.battery > 40
                    ? "bg-yellow-500/10 border-yellow-500"
                    : "bg-red-500/10 border-red-500"
                }
              `}
            >

              <h2 className="
                text-2xl
                font-bold
                mb-3
              ">
                {device.name || device.device}
              </h2>

              {/* Status Badge */}

              <div
                className={`
                  inline-block
                  px-3 py-1
                  rounded-full
                  text-sm
                  font-bold
                  mb-4
                  ${
                    device.battery > 70
                      ? "bg-green-500 text-black"
                      : device.battery > 40
                      ? "bg-yellow-400 text-black"
                      : "bg-red-500 text-white"
                  }
                `}
              >
                {
                  device.battery > 70
                    ? "OPTIMAL"
                    : device.battery > 40
                    ? "WARNING"
                    : "CRITICAL"
                }
              </div>

              <p className="mb-2">
                Voltage:
                {" "}
                {device.voltage}V
              </p>

              <p className="mb-2">
                Battery:
                {" "}
                {device.battery}%
              </p>

              <p>
                Power:
                {" "}
                {device.power}W
              </p>

            </div>

          ))}

        </div>

        {/* Add Device Modal */}

        {
          showModal && (

            <div className="
              fixed inset-0
              bg-black/60
              flex items-center
              justify-center
              z-50
            ">

              <div className="
                bg-[#111827]
                p-8
                rounded-2xl
                w-full
                max-w-md
                border
                border-white/10
              ">

                <div className="
                  flex items-center
                  justify-between
                  mb-6
                ">

                  <h2 className="
                    text-2xl
                    font-bold
                  ">
                    Register Device
                  </h2>

                  <button
                    onClick={() =>
                      setShowModal(false)
                    }
                    className="
                      text-red-400
                      text-xl
                    "
                  >
                    ✕
                  </button>

                </div>

                <div className="space-y-4">

                  <input
                    value={deviceId}
                    onChange={(e) =>
                      setDeviceId(
                        e.target.value
                      )
                    }
                    placeholder="Device ID"
                    className="
                      w-full
                      p-4
                      rounded-xl
                      bg-black/30
                      border
                      border-white/10
                    "
                  />

                  <input
                    value={deviceName}
                    onChange={(e) =>
                      setDeviceName(
                        e.target.value
                      )
                    }
                    placeholder="Device Name"
                    className="
                      w-full
                      p-4
                      rounded-xl
                      bg-black/30
                      border
                      border-white/10
                    "
                  />

                  <button
                    onClick={() => {

                      handleAddDevice();

                      setShowModal(false);

                    }}
                    className="
                      w-full
                      bg-cyan-500
                      text-black
                      py-3
                      rounded-xl
                      font-bold
                    "
                  >
                    Register Device
                  </button>

                </div>

              </div>

            </div>

          )
        }

      </section>

    </main>

  );
}