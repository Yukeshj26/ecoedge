"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const menu = [
  {
    name: "Overview",
    path: "/",
  },
  {
    name: "Devices",
    path: "/devices",
  },

  {
    name: "Analytics",
    path: "/analytics",
  },
  {
    name: "AI Predictions",
    path: "/predictions",
  },
  {
    name: "Alerts",
    path: "/alerts",
  },
  {
    name: "Settings",
    path: "/settings",
  },
];
export default function Sidebar() {

  const pathname = usePathname();

  return (
    <aside className="w-64 bg-[#0F172A] border-r border-white/10 p-6">

      <h1 className="text-4xl font-bold text-cyan-400 mb-10">
        EcoEdge
      </h1>

      <nav className="space-y-3">

        {menu.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`
              block px-4 py-3 rounded-xl transition
              ${
                pathname === item.path
                  ? "bg-cyan-500 text-black font-bold"
                  : "hover:bg-white/10"
              }
            `}
          >
            {item.name}
          </Link>
        ))}

      </nav>

    </aside>
  );
}